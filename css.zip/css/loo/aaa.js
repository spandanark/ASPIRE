var overlay = document.querySelector('.skw-pages');
window.addEventListener('load', function(){
function sayHi() {
overlay.style.display = 'none';
}

setTimeout(sayHi, 2000);
overlay.style.display = 'none';
});</